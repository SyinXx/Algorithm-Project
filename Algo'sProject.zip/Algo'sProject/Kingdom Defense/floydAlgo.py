'''
Name: Abdelrhman Hussien Farouk.
ID: 692400340.
Group: A2.
Algorithm: Floyd-warshall.
'''

def floyed(W):
  n = len(W)
  D = [row[:] for row in W]
  for k in range(n):
    for i in range(n):
      for j in range(n):
        D[i][j] = min(D[i][j], D[i][k] + D[k][j]) # O(1)
  
  # since its three loops then n * n * n = n^3 then O(n^3) is the time complexity.
  return D

