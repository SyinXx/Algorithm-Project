'''
Name: Rokaya Waleed Mohamed.
ID: 692400090.
Group: B3.
Algorithm: Dijkstra.
'''

import heapq # we use heapq for pushing and poping the elements

def dijkstra(graph, start, end):
  # let the node = infinity.

  dist = {node: float("inf") for node in graph}
  dist[start] = 0
  pq = [(0, start)]

  while pq:
    cost, node = heapq.heappop(pq)
    if node == end:
      return cost
    for neighbor, weight in graph[node]:
      new_cost = cost + weight
      if new_cost < dist[neighbor]:
        dist[neighbor] = new_cost
        heapq.heappush(pq, (new_cost, neighbor))
  return float("inf")
